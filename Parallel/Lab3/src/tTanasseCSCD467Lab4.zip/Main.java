import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Created by moth on 1/19/16.
 */
public class Main {
    ConcurrentLinkedQueue<Thread> threads;
    int messageCount = 0;
    Object lock;

    public static void main(String[] args) {
        Main main = new Main();
    }

    public Main(){
        threads = new ConcurrentLinkedQueue<>();
        lock = new Object();
        this.addThreads(2);
        ConcurrentLinkedQueue<Thread> copy = new ConcurrentLinkedQueue<>();
        copyQueue(copy, threads);
        startThreads(copy);
        joinThreads(copy);
    }

    private void addThreads(int n){
        for(int i = 0; i < n; i++) {
            threads.add(new Thread(new MessageWriter(i+1)));
        }
    }

    private static void copyQueue(ConcurrentLinkedQueue<Thread> dest, ConcurrentLinkedQueue<Thread> source){
        for (Thread t: source){
            dest.add(t);
        }
    }

    private static void startThreads(Iterable<Thread> threads){
        for(Thread t: threads){
            t.start();
        }
    }

    private void joinThreads(Iterable<Thread> threads){
        for (Thread t: threads){
            try {
                t.join();
            } catch (InterruptedException e) {
            }
        }
    }

    private class MessageWriter implements Runnable{
        private int id;

        public MessageWriter(int id){
            this.id = id;
        }

        @Override
        public void run() {
            while(messageCount < 50) {
                synchronized (lock) {
                    if (threads.peek() == Thread.currentThread() && messageCount < 50) {
                        messageCount++;
                        System.out.println("Message " + messageCount + " from thread: " + id);
                        threads.add(threads.poll());
                        //lock.notifyAll();
                        //try {lock.wait();} catch (InterruptedException e) {}
                    }else if (messageCount <50){
                        //lock.notify();
                        //try {lock.wait();} catch (InterruptedException e) {}
                    }else{
                        //lock.notifyAll();
                    }
                }
            }
        }
    }
}
