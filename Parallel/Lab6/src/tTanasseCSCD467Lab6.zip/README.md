Name: Tim Tanasse

Compile: javac *

run: java MyBarrierTester

Hi John!
