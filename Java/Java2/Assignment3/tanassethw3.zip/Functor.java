public interface Functor{
   public LongInteger function(LongInteger other);
   //public boolean functionCheck(LongInteger other);
}