/* Tim Tanasse
 * Assignment 3: LongInteger Inheritence
 * April 28th, 2015
 * EC attempted: Negatives and Custom Conversion Methods
 */
public class IntDriver {
   public static void main(String[] args){
   Calculator calculator = new Calculator();
   calculator.run();
   }
}