public class NumberMismatchException extends Exception{
   public NumberMismatchException(String msg){
      super(msg);
   }
   
   public NumberMismatchException(){}
}