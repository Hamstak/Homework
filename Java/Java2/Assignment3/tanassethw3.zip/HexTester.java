public class HexTester{
   public static void main(String[] args){
      long hexTest = Integer.parseInt("aaa", 16);
      System.out.print(hexTest);
   }
}