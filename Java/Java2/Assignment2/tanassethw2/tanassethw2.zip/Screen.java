public interface Screen{
   public void display();
   
   public Screen respondToUserInput();
   
   public void repaint();
}