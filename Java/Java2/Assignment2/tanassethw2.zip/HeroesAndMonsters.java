/* Tim Tanasse
 * April 15th, 2015
 * Assignment 2: Inheretince; Heros and Monsters
 * EC Attempted: Monster Special Attacks and Additional Class
 */

public class HeroesAndMonsters{
   public static void main(String[] args){
      Screen screen = new StartScreen();
   }
}