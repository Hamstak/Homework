/* Tim Tanasse
 * Search/Sort Utility Class
 */


public class SortSearchUtil {
	
	public static void selectionSort(int[] ara){
		int temp = 0;
		int indexSmallest = 0;
		for (int posFill = 0; posFill < (ara.length - 1); posFill++){
			indexSmallest = posFill;
			for (int current = posFill + 1; current < ara.length; current++){
				if (ara[current] < ara[indexSmallest]){
					indexSmallest = current;
				}
			}
			temp = ara[posFill];
			ara[posFill] = ara[indexSmallest];
			ara[indexSmallest] = temp;
		}
	}
	public static boolean linearSearch(int[] ara, int target){	//searches through a 1d int array and reports true if a given
		for (int i = 0; i < ara.length; i++){					// value is contained
			if (ara[i] == target){
				return true;
			}
		}
		return false;
	}
	public static int linearSearchComplex( int[] ara, int target){	//searches through a 1d int array and reports the index
		for (int i = 0; i < ara.length; i++){						//if a given value is there, otherwise reports -1
			if (ara[i] == target){
				return i;
			}
		}
		return -1;
	}
	public static void revArray(int[] input){
		int temp;
		for(int i = 0; i <= input.length/2; i++){
			temp = input[i];
			input[i] = input[input.length - i - 1];
			input[input.length - i - 1] = temp;
		}
	}
/*	public static void quickSort(int[] input, int start, int end){
		int index = partition(input, start, end);
		if (start < index - 1){
			quickSort(input, start, index - 1);
		}
		if (index < end){
			quickSort(input, index, end);
		}
	}
	private static int partition(int[] input, int start, int end){
		int leftIndex = start, rightIndex = end;
		int temp = 0;
		int pivot = input[(leftIndex+rightIndex) / 2];
		while (leftIndex < rightIndex){
			while (input[leftIndex] < pivot){
				leftIndex++;
			}while (input[rightIndex] < pivot){
				rightIndex--;
			}
		}
*/	}
}

