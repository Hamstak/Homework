#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
    int data;
    struct node *next;
}Node;


int main()
{
    Node f;
    Node last;
    f.data = 1;
    f.next = &last;

    return 1;
}


