#include<stdio.h>

int main()
{
    int inum = 8;
    float fnum = 67.7;
    void *ptr;

    ptr = &inum;  
    printf("\nThe value of inum = %d",*((int*)ptr));
    //printf("\nThe value of inum = %d",*(ptr));

    ptr = &fnum;  
    printf("\nThe value of fnum = %f\n",*((float*)ptr));

    return(0);
}

