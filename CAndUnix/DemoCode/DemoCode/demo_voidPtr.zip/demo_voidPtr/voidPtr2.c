#include<stdio.h>

int main()
{
    int inum = 8;
    void *ptr;

    ptr = (void *)inum;  
    printf("\nThe value of inum = %d\n",(int)(ptr)); //this works, but not a good practice

    return(0);
}

