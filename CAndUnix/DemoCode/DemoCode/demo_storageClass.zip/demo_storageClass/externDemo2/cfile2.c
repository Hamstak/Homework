#include <stdio.h>

extern int v;

int myfunct()
{
        //extern int v;
        v = 200;
/*
        {	
		int v = 100;
		printf("v(fromInsideBlock):%d\n", v);
	}
*/	
	printf( "v(from myfunct):%d\n", v );
	return 0;
}
