#include <stdio.h>

int myrandom();

int main()
{
	int i;
	for( i = 0; i < 5; i ++ )
		printf("%d\n", myrandom() );

}

int myrandom()
{
	static int seed = 10;
	seed = seed + 1;
	return seed;
}
