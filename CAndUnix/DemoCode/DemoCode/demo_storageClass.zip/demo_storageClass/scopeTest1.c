#include <stdio.h>

int myfunc(int in)
{
	int j = in;
        int a = 10;
	printf("j:%d\n", j);
	{
		int a = j ++;
		printf("a in block:%d\n", a);
	}
	printf("a ouside of block in funciton:%d\n",a);
        return 0;
}

int main()
{
	myfunc(100);
	return 0;
}



