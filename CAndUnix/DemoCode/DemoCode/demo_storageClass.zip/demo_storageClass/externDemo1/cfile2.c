#include <stdio.h>

int myfunct()
{
	extern int v;  //you have to declare the global variable before you use it. otherwise get an error!
	{
		int v = 100;
		printf("v(fromInsideBlock):%d\n", v);
	}
	printf( "v(from myfunct):%d\n", v );
	return 0;
}
