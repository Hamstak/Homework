#include <stdio.h>
int v = 5; 
extern int myfunct();

int main()
{
	printf("v(from main):%d\n", v);
	myfunct();
}

