#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
    int data;
    struct node *next;
}Node;


Node* addFirst(Node *head, int value)
{
     Node *var=(Node *)malloc(sizeof (Node));
     var->data=value;
     if(head==NULL)
     {
         head=var;
         head->next=NULL;
     }
     else
     {
         var->next=head;
         head=var;
     }
     return head;
}

void addLast(Node **head, int value)
{
      Node *temp; 
      temp = *head;
      Node *var = (Node *)malloc(sizeof (Node));
      var->data=value;
      if( *head==NULL)
      {
          *head=var;
          (*head)->next=NULL;
      }
      else
      {
          while(temp->next!=NULL)
          {     
               temp=temp->next;
          }
          var->next=NULL;
          temp->next=var;
      }
}

Node* removeLast( Node *head )
{
     Node *temp;
     temp=head;
     Node *prev;
     if(head == NULL)
     {
         printf("Error, try to remove a node from empty list!\n");
         return NULL;
     }
     while(temp->next != NULL)
     {
          prev=temp;
          temp=temp->next;
     }
     if(temp == head)
     {
          head=temp->next; 
          free(temp);
          return head;
     }
     printf("data deleted from list is %d",temp->data);
    
     prev->next = NULL;
     free(temp);
 
     return head;
}

void display( Node *head )
{
     Node *trav=head;
     if(trav==NULL)
     {
          printf("\nList is Empty");
     }
     else
     {
          printf("\nElements in the List: ");
          while(trav!=NULL)
          {
               printf(" -> %d ",trav->data);
               trav=trav->next;
          }
      printf("\n");
      }
}

int main()
{
    printf("Initially list is empty.\n");
    Node *head = NULL;
    printf("Add number at the end of list: 9");
    addLast(&head, 9);
    display(head);
    
    printf("Add number at the end of list: 7");
    addLast(&head, 7);
    display(head);   
    
    printf("Add number at head of the list: 2");
    head = addFirst(head, 2);
    display(head); 

    printf("Add number at head of the list: 1");
    head = addFirst(head, 1);
    display(head);    
 
    printf("Remove number at end of the list:");
    head = removeLast(head);
    display(head);

    return 0;
}
