#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define MAX 100

typedef struct node
{
    int data;
    char *name;
    struct node *next;
}Node;

Node* addFirst(Node *head, int value, char *s)
{
     Node *var=(Node *)malloc(sizeof (Node));
     var->data=value;
     var->name = (char *)malloc( MAX * sizeof(char));
     strcpy(var->name, s);

     if(head==NULL)
     {
         head=var;
         head->next=NULL;
     }
     else
     {
         var->next=head;
         head=var;
     }
     return head;
}


void display( Node *head )
{
     Node *trav=head;
     if(trav==NULL)
     {
          printf("\nList is Empty");
     }
     else
     {
          printf("\nElements in the List: ");
          while(trav!=NULL)
          {
               printf(" -> (%d,%s) ",trav->data, trav->name);
               trav=trav->next;
          }
          printf("\n");
      }
}

void freeList( Node *head )
{
    Node *cur = head, *temp;
    while(cur != NULL)
    {
        temp = cur;
        cur = cur->next; //this has to be here, cannot moved to the end of while loop, why?
        free(temp->name);//the order of these two free() matters!
        free(temp);
        temp = NULL;
    }
}


int main()
{
    printf("Initially list is empty.\n");
    Node *head = NULL;
    
    printf("Add info at head of the list: (2, John)");
    head = addFirst(head, 2, "John");
    display(head); 

    printf("Add info at head of the list: (1, Smith)");
    head = addFirst(head, 1, "Smith");
    display(head);    
    
    freeList(head); 
    printf("All memory have been freed!\n");
    return 0;
}
