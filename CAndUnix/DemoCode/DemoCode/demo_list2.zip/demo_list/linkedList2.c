#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
    int data;
    struct node *next;
}Node;
Node *head = NULL; //global list head, each file or each function could change that

// add value into list pointed by global variable head.
// you do not need pass in head, or return head, 
// because the global variable you changed in function
// will be visible to outside of the function

// BUT in software engineering, in real-world applications, or in industry
// This style of using global variables to pass information around, is prohibited. 
// That is because it breaks structured design principles.
// We like each module is as independent as possible, (data passed around through clean interface)
// Using global variables makes code harder to debug and maitain, and readable, called "spaghetti code".
void addFirst(int value)
{
     Node *var = (Node *)malloc(sizeof (Node));
     var->data = value;
     if(head == NULL)
     {
         head = var;
         head->next = NULL;
     }
     else
     {
         var->next = head;
         head = var;
     }
}

void addLast(int value)
{
      Node *temp; 
      temp = head;
      Node *var = (Node *)malloc(sizeof (Node));
      var->data = value;
      if(head == NULL)
      {
          head = var;
          head->next = NULL;
      }
      else
      {
          while(temp->next!=NULL)
          {     
               temp=temp->next;
          }
          var->next=NULL;
          temp->next=var;
      }
}

void removeLast()
{
     Node *temp;
     temp = head;
     Node *prev;
     while(temp->next != NULL)
     {
          prev = temp;
          temp = temp->next;
     }
     if(temp == head)
     {
          head = temp->next; 
          free(temp);
     }
     printf("data deleted from list is %d",temp->data);
     prev->next=NULL;
     free(temp);
}

void display()
{
     Node *trav = head;
     if(trav == NULL)
     {
          printf("\nList is Empty");
     }
     else
     {
          printf("\nElements in the List: ");
          while(trav != NULL)
          {
               printf(" -> %d ",trav->data);
               trav = trav->next;
          }
          printf("\n");
      }
}

int main()
{
    printf("Initially list is empty.\n");
    printf("Add number at the end of list: 9");
    addLast(9);
    display();
    
    printf("Add number at the end of list: 7");
    addLast(7);
    display();   
    
    printf("Add number at head of the list: 2");
    addFirst(2);
    display(); 

    printf("Add number at head of the list: 1");
    addFirst(1);
    display();    
 
    printf("Remove number at end of the list:");
    removeLast();
    display();

    return 0;
}
