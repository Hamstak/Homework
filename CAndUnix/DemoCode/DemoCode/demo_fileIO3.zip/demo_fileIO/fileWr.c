#include <stdio.h>

int main()
{
   FILE *fp;
   
   int i = 77;
   char *s = "this is a line.";
   fp = fopen("writeTest.txt", "w+");
   fprintf(fp, "This is testing for fprintf...\n");
   fprintf(fp, "line2: %s\n", s);
   
   fputs("This is testing for fputs...\n", fp);
 
   fprintf(fp,"%d\n", i);
   fclose(fp);
}

