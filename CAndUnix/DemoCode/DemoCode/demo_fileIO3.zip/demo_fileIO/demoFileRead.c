#include <stdio.h>
int main()
{
   FILE *fp;
   int numStudent = 0;
   int oneGrade;
   char fileName[255];

   printf("Please input the file name you like to open:");
   scanf("%s", fileName);
   printf("the input string is \"%s\"\n ", fileName);

   fp = fopen(fileName, "r");//open file to to read
   
   while( fscanf(fp, "%d", &oneGrade) == 1 )
   {
       //if(feof(fp)) //check if file pointer reached the end of file
       //    break;   //if end of file, we break the loop.

       numStudent ++;
       printf("The current grade read in is %d\n ", oneGrade);
   }

   printf("The total number of  grades read in is %d\n ", numStudent );
   fclose(fp);//close file pointer
}
