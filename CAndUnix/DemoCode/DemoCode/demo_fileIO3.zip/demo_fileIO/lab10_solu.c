#include <stdio.h>
#include <stdlib.h>

/*
int main()
{
   FILE *fp;
   int numStudent = 0;
   int oneGrade;
   char fileName[255];

   printf("Please input the file name you like to open:");
   scanf("%s", fileName);
   printf("the input string is \"%s\"\n ", fileName);

   fp = fopen(fileName, "r");//open file to to read
   
   while( fscanf(fp, "%d", &oneGrade) == 1 )
   {
       //if(feof(fp)) //check if file pointer reached the end of file
       //    break;   //if end of file, we break the loop.

       numStudent ++;
       printf("The current grade read in is %d\n ", oneGrade);
   }

   printf("The total number of  grades read in is %d\n ", numStudent );
   fclose(fp);//close file pointer
}
*/


int * readIntFile( char filename[], int *numItem )
{
   FILE *fp;
   int numStudent = 0;
   int oneGrade;
   printf("the input string is \"%s\"\n ", filename);

   fp = fopen(filename, "r");//open file to to read
   if(fp == NULL)
   {
       printf("error when open file\n");
       return NULL;
   }
   while( fscanf(fp, "%d", &oneGrade) == 1 )
   {
       //if(feof(fp)) //check if file pointer reached the end of file
       //    break;   //if end of file, we break the loop.

       numStudent ++;
       //printf("The current grade read in is %d\n ", oneGrade);
   }
   rewind(fp);

   int *ret = (int*) malloc(numStudent * sizeof(int));
   int *cur = ret;
   while( fscanf(fp, "%d", &oneGrade) == 1 )
   {
       *(cur ++) = oneGrade;
       //printf("The current grade read in is %d\n ", oneGrade);
   }
    
   fclose(fp);//close file pointer
   //printf("The total number of  grades read in is %d\n ", numStudent );
   *numItem = numStudent;
   return ret;
} 

int main()
{

    char name[] = "./grades.txt";
    int size;
    int *grades = readIntFile(name,&size);
    int i;
    printf("Total number of integers read in is: %d\n", size);

    for( i = 0; i < size; i ++ )
    {
        printf("The %d th grade number is %d\n", i, *(grades + i));
    }
}
   
