#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXSIZE 100

int main()
{
        char line[MAXSIZE];
	int i;
	FILE *fp = fopen("test2","r");

        while(fgets(line, MAXSIZE, fp) != NULL )
        {
                sscanf(line, "%d",&i); 
                printf("\"%d\"\n", i);
        }
}


