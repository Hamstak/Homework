#include <stdio.h>
#include <stdlib.h>
#include <string.h>



int main()
{
	char line[100];
	FILE *fp = fopen( "test1", "r");
	while( 1 )
	{
		if (fgets(line, 100, fp) == NULL )
			break;
		line[strlen(line)-1] = '\0';
		printf("\"%s\"\n", line);
	}
	fclose(fp);
}

