#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NUMLINE 4

char* readOneLine(FILE *fp);

int main()
{
    char *lines[NUMLINE];
    int i;

    char *fileName = "test3";
    FILE *fp = fopen(fileName, "r");

    for(i = 0; i < NUMLINE; i ++) 
    {
    	lines[i] = readOneLine(fp);
    	//printf("The current line read in is \"%s\"\n", line);
    }

    for(i = 0; i < NUMLINE; i ++)
    {   
        printf("The current line read in is \"%s\"\n", lines[i]);
    }
}

// read in one line and store in a piece of memory without wasting space
char* readOneLine(FILE *fp)
{
    char temp[100];
    //FILE *fp = fopen(fileName, "r");
    fgets(temp, 100, fp);
    
    char *ret = (char *)malloc( (strlen(temp) + 1 ) * sizeof(char)); //must include the termination character
    strcpy(ret, temp);
    printf("The memory used to store current line is %lu\n", strlen(ret) + 1);
    //printf("The current line read in is \"%s\"\n", ret);

    return ret;
}
