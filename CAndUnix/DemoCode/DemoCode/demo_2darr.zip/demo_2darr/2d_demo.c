#include <stdio.h>

#define R 3
#define C 4

void printOneRow( int *row, int cols );
void print2D1( int a[][C], int, int);
void print2D2( int **a, int, int);


//2D static array decays to a poiter to an array, a[R][C]=> (*a)[C], a pointer points to a 1D array of size C.
int main()
{
    int a[R][C] = { 
                   { 1, 2, 3, 4 },
                   { 5, 6, 7, 8 },
                   { 9, 11, 12, 13}
                  };
    int *p = a[0];
    int i;
 
    for( i = 0; i < R * C; i ++)
    {
        if(i % C == 0)
            printf("\n");

        printf("%3d", *(p + i));

    }
    puts("");

    printf("The value of (a + 1)=%p, and *(a+1)=%p\n", a + 1, *(a + 1)); //Only for 2D static array name,
						    //they are the same. Not true for pointer to pointer. 

    //
    puts("The second row is: ");
    printOneRow( a[1], C );

    puts("call print2D function:");

    //int **pptr =(int **) a;
    print2D1(a, R, C);
    //print2D2(pptr, R, C);
/*
    int j = 0;
    for(i = 0; i < R; i ++)
    {
       for(j = 0; j < C; j ++ )
           //printf("%3d", a[i][j]);
           printf("%3d", *(*(a + i) + j));

       puts("");
    }
*/

    return 0;
}


void printOneRow( int *row, int cols )
{
    int i;
    for( i = 0; i < cols; i ++ )
      printf("%3d", *(row ++));

    printf("\n");
}    


void print2D1( int a[][C], int rows, int cols )
{
    int i = 0, j = 0;
    for(i = 0; i < rows; i ++)
    {
       for(j = 0; j < cols; j ++ )
           //printf("%3d", a[i][j]);
           printf("%3d", *(*(a + i) + j));
       
       puts("");
    }    
}

//this function below does not work, if you pass in a 2D static array name
void print2D2( int **a, int rows, int cols )
{
    int i = 0, j = 0;
    for(i = 0; i < rows; i ++)
    {
       for(j = 0; j < cols; j ++ )
           //printf("%3d", a[i][j]);
           printf("%3d", *(*(a + i) + j));

       puts("");
    }   
}

