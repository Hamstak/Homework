#include <stdio.h>
#define A 1

void myPrintHelloMake(void) 
{ 
    int i = 100;
    printf("Hello makefiles!\n"); 
    return; 
}

