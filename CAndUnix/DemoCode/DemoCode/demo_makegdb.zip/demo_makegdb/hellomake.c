#include "hellomake.h"
#define N 100

int main() 
{ 
    // call a function in another file 
    myPrintHelloMake();
    return(0);
 }

