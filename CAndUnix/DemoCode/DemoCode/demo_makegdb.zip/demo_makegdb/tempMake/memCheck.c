#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void foo( int i, int j );


int main()
{
   char name[100];
   char *description;

   strcpy(name, "Zara Ali");

   foo(10, 20);

   /* allocate memory dynamically */
   description = malloc( 200 * sizeof(char) );
   if( description == NULL )
   {
      fprintf(stderr, "Error - unable to allocate required memory\n");
   }
   else
   {
      strcpy( description, "Zara ali a DPS student in class 10th");
   }
  
   printf("Name = %s\n", name );
   printf("Description: %s\n", description );
   free(description);
}


void foo( int i, int j )
{
        int z = i + j * 1000;
        for( i = 0; i < 10000; i ++ )
        {       
                printf( "%d,\n", i );
        }
        //just do some juck work
}

