#include <stdio.h>

char s[] = "ABC"; //global array, initialized by copying the charaters into array s including the '\0';
char *p = "a is for apple or alphabet pie";  //global pointer variable, initialized with the address that points to 
                                             // the string as stored in memory(cannot be overwritten). 

int main()
{
	char *q = "which all get a slice of, come taste it and try";
	
	printf("\nstring s is:%s,  string p is:%s, string q is:%s \n", s, p, q);
	printf("p: %p q: %p s: %p\n", p,q,s);
	for( p = s; *p != '\0'; ++p)
	{
		printf("p: %p | *p: %c\n", p, *p);
	        p[0]++;
	}
	printf("\n  %s\n\n", s);
}


