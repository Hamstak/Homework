#include <stdio.h>

char s[] = "ABC"; //global variable, initialized by copying the charaters into array s including the '\0';
char *p = "a is for apple or alphabet pie";  //global variable, initialized with the address that points to 
                                             // the string as stored in memory(cannot be overwritten). 

int main()
{
	char *q = "which all get a slice of, come taste it and try";
        char *c ;
	
	printf("\nstring s is:%s,  string p is:%s, string q is:%s \n", s, p, q);
	printf("p: %p q: %p s: %p\n", p,q,s);
	for( c = s; *c != '\0'; ++c)
	{
		//printf("p: %p | *p: %c\n", p, *p);
	       c[0]++;
	}
	printf("\n  %s\n\n", s);
}


