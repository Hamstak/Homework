#include <stdio.h>
#include <string.h>


int main()
{
	void strcpy1( char s[], char t[] );
	void strcpy2( char *s, char *t );
	void strcpy3( char *s, char *t );
	void strcpy4( char *s, char *t );

	char s1[50], *s2;
	strcpy( s1, "a string");
	s2 = "this is a literal string";
	printf("s1: %s\ns2: %s\n", s1, s2);
	
	strcpy1( s1, s2 );
	printf("s1: %s\ns2: %s\n", s1, s2);
}

void strcpy1( char s[], char t[] )
{
	int i = 0;
	while(( s[i]=t[i] ) != '\0' )
	{
		s ++;
		t ++;
	}
}

void strcpy2( char *s, char *t )
{
	while(( *s = *t ) != '\0' )
        {
                s ++;
                t ++;
        }
}

void strcpy3( char *s, char *t )
{
        while(( *s++ = *t++ ) != '\0' );
}

void strcpy4( char *s, char *t )
{
        while(( *s++ = *t++ ));
 
}

// *ptr++ seems confusing. It is allowed and legal in C.
// the precedence order says ++ and * ( dereferencing ) fall into a same precedence order category,
// but has an associativity of Right to Left. 
// That is, *ptr++ =====>  *(ptr ++ )
// If yor are not sure in programming, it does not hurt to put your parens
