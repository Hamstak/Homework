#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    double vol = 3.55;
    int age = 65;
    float grade;    

    //convert to string using sprintf
    char strNum[10];
    char strDouble[10];
    sprintf(strNum, "%d", age);
    printf("strNum is \"%s\"\n", strNum);
    sprintf(strDouble, "%f", vol);
    printf("strDouble is \"%s\"\n", strDouble);


   //Assume we have this string, we try to read from the string the numerical value 98.5
   char *info = "The grade for student A is 98.5";
   char dummy[10];
   sscanf(info, "%s %s %s %s %s %s %f", dummy, dummy, dummy, dummy, dummy, dummy, &grade);
   printf("The numerical grade is %f\n", grade);  

   //demo of atoi and atof
   char *strInt = "345";
   char *strFlt = "0.456";
   int anum = atoi(strInt);
   float aflt = atof(strFlt);
   printf("The numerical integer number is %10d \n", anum);
   printf("The numerical float number is %10f \n", aflt);  

   //NOTE:  int anum = (int) strInt; this will not conver the string representation to an integer!   
}
