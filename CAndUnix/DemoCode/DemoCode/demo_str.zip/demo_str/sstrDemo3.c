#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char s[] = "ABC"; //global array, initialized by copying the charaters into array s including the '\0';
char *p = "a is for apple or alphabet pie";  //global pointer variable, initialized with the address that points to 
                                             // the string as stored in memory(cannot be overwritten). 

int main()
{
	char *q = "which all get a slice of, come taste it and try";
/* 
        char copyQ1[100] = q;	
	printf("\nstring copyQ1 is:%s, string q is:%s \n", copyQ1, q);
*/
/*
        char *copyQ2 = q;
        printf("\nstring copyQ2 is:%s, string q is:%s \n", copyQ2, q);
*/
/*
        char *copyQ3 = NULL;
        strcpy(copyQ3, q);        
        printf("\nstring copyQ3 is:%s, string q is:%s \n", copyQ3, q);
*/
/*
        char copyQ4[100];
        strcpy(copyQ4, q);
        printf("\nstring copyQ4 is:%s, string q is:%s \n", copyQ4, q);
*/
        char *copyQ5 = (char *) malloc(100 * sizeof(char));
        strcpy(copyQ5, q);
        printf("\nstring copyQ5 is:%s, string q is:%s \n", copyQ5, q);

}


