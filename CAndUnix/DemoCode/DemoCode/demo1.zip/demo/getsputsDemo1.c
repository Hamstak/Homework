#include <stdio.h>
int main( )
{
   char str[100];

   printf( "Enter a value :");
   gets( str );//gets() also append a linefeed at end of the string

   printf( "You entered: ");
   puts( str );

   
   puts( "goodman" ); //puts() output the string, then trailing a newline
   printf("at nextline?\n");

   return 0;
}

