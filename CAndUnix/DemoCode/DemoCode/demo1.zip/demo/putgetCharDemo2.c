#include <stdio.h>
int main( )
{
   int c;
   char dummy[10];

   printf( "Enter a value :");
   c = getchar( );
   //gets(dummy);
   fgets(dummy, 10, stdin);

   while( c != 'q' && c != 'Q' )
   {
       printf( "You entered: ");
       putchar( c );
       printf("\n");
    
       printf("Enter a value :"); 
       c = getchar();
       //gets(dummy);
       
       fgets(dummy, 10, stdin);
   }
   return 0;
}

