#include <stdio.h>
int main( )
{
   char str[10];
   int i;

   printf( "Enter a string and an integer :");
   scanf("%s %d", str, &i);// The & is required in this program. The input integer will be stored 
                           // at the address of variable i.
                           //read string only, discard the newline
                           //one or more spaces are allowed between the string and the integer
                           // It is ok to use enter to separate the string and the integer
   printf( "\nYou entered: \"%s\", \"%d\"", str, i);

   return 0;
}
