#include <stdio.h>
int main( )
{
   int c;

   printf( "Enter a value :");
   c = getchar( );

   while( c != 'q' && c != 'Q' )
   {
       printf( "You entered: ");
       putchar( c );
       printf("\n");
    
       printf("Enter a value :"); 
       c = getchar();
   }
   return 0;
}

