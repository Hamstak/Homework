#include <stdio.h>
int main( )
{
   char str[100];
   int i, j;

   printf( "Enter two  integers separated by comma :");
   scanf("%d,%d", &i, &j); //after conversion, newline is discarded!

   printf( "You entered: \"%d\", \"%d\"\n", i, j);

   printf( "Enter two  integers separated by comma :");
   scanf("%d,%d", &i, &j); //
   printf( "You entered: \"%d\", \"%d\"\n", i, j);

   return 0;
}
