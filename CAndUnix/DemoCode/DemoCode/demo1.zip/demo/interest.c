#include <stdio.h>
#include <math.h>
int main()
{
    int year = 1990;
    double rate = 1.2f;
    double amount = 1000.0f;
    int i;
 
    printf( "%4s%21s\n", "Year", "Amount on Year" );
    for( i = 0; i < 10; i ++ )
    {
        amount = amount * pow(rate, i);
        printf( "%4d%21.2f\n", year ++, amount );
    }
}

