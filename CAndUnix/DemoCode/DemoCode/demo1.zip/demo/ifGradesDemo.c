#include <stdio.h>
#include <stdlib.h>
 
int main ()
{
   /* local variable definition */
   int a = 0;
   printf("Please input numerical grades:");
   scanf("%d", &a);
   
   if( a < 0 || a > 100 )
   {
       printf("You have input data in wrong format!\n");
       exit(1);
   }
   /* check the boolean condition */
   if( a >= 90 )
   {
       /* if condition is true then print the following */
       printf("The students gets a A!\n" );
   }
   else if( a >= 80 )
   {
       /* if else if condition is true */
       printf("The students gets a B!\n" );
       
   }
   else if( a >= 70 )
   {
       /* if else if condition is true  */
       printf("The students gets a C!\n" );
   }
   else if( a >= 60 )
   {
       /* if this conditions is true */
       printf("The students gets a D!\n" ); 
   }
   else
       printf("The student fail this class!\n");

   printf("The input grade value is: %d\n", a ); 
   return 0;
}

