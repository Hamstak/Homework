#include <stdio.h>

int main()
{
    int a = 2;
    int b = 3;
    //int c = a ++ +++b;//compile error

    int c = a ++ + ++b;//this one works.
    int d =  sizeof + ++a;
    printf("c is %d\n", c);
    printf("d is %d\n", d);
}
