#include <stdio.h>

int main()
{
    int i = 0;
    int grade, sum = 0;
    printf("please input 10 grades, separated by comma :");
    while(i < 10)
    {
        scanf("%d,", &grade);
        sum += grade; 
        i ++;
    }
    printf( "Average grade for 10 students is %5.2f\n", (double)sum / 10 );
}
