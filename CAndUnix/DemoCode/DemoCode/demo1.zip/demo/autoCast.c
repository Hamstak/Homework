#include <stdio.h>

int main()
{
    double d = 12.4f;
    int i = 12;
    float f = 3.2f;
    double d2 = 2.f;
    float d3 = 210e3;

    printf("size of result = %lu\n",sizeof(d / i) );

    printf("size of int is %lu\n",sizeof(i) );

    printf("size of double is %lu\n",sizeof(d) );
    printf("result = %.2f\n",d / i );
    printf("size of (d/i) is %lu\n", sizeof(d / i));
} 

