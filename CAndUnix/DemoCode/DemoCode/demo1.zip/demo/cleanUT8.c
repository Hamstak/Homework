#include <stdio.h>

int main() {

    int c;
    while(1) {
        c = getchar();
        if (c == EOF)
		break;
        if(c >=0 && c <= 128)
		putchar(c);
    }
}
