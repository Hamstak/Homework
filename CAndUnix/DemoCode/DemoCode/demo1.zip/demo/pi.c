#include <stdio.h>

int main( void )
{ 
   double pi = 0.0; // approximated value for pi
   double num = 4.0; // numerator
   double denom = 1.0; // denominator of current term
   unsigned int loop; // loop counter
   unsigned int accuracy; // number of terms

   accuracy = 400000; // set decimal accuracy
   
   // display table headers
   printf( "Accuracy set at: %u\n", accuracy );
   puts( "term\t\t  pi" );

   // loop through each term
   for ( loop = 1; loop <= accuracy; ++loop ) { 

      // if odd-numbered term, add current term
      if ( loop % 2 != 0 ) {
         pi += num / denom;
      } // end if
      else { // if even-numbered term, subtract current term
         pi -= num / denom;
      } // end else

      // display number of terms and approximated 
      // value for pi with 6 digits of precision
      printf( "%u\t\t%f\n", loop, pi );

      denom += 2.0; // update denominator
   } // end for
} // end main


