#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* function to generate and return random numbers */
int * getRandom( )
{
  int  *r = (int*) malloc(10 * sizeof(int));
  int i;

  /* set the seed */
  srand( (unsigned)time( NULL ) );
  for ( i = 0; i < 10; ++i)
  {
     r[i] = rand() % 101; //generate random number between 0 to 100
     // using *(r + i) in place of r[i] is also work in the previous statement

     printf( "r[%d] = %d\n", i, r[i]);

  }

  return r;
}

/* main function to call above defined function */
int main ()
{
   /* a pointer to an int */
   int *p;
   int i;

   p = getRandom();
   for ( i = 0; i < 10; i++ )
   {
       printf( "*(p + %d) : %d\n", i, *(p + i));
       //printf( "*(p + %d) : %d\n", i, p[i] );
   }

   return 0;
}
