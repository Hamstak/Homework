#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
   char name[100];
   char *description;
   int numChar;

   strcpy(name, "Zara Ali");

   printf("Please input how many characters you will use for the description:");
   scanf("%d",&numChar);

   /* allocate memory dynamically */
   description = malloc( numChar * sizeof(char) ); //you could use calloc(numChar, sizeof(char))
   if( description == NULL )
   {
      fprintf(stderr, "Error - unable to allocate required memory\n");
   }
   else
   {
      strcpy( description, "Zara ali a DPS student in class 10th");
   }
   printf("Name = %s\n", name );
   printf("Description: %s\n", description );
}
