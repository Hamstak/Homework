#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* function to generate and return random numbers */
void getRandom(int size, int **r)
{
  *r = (int *) malloc(size * sizeof(int));
  int i;

  /* set the seed */
  srand( (unsigned)time( NULL ) );
  for ( i = 0; i < size ; ++i)
  {
     *(*r + i) = rand() % 101; //generate random number between 0 to 100
     //(*r)[i] = rand() % 101;
 
     printf( "*(*r + %d) = %d\n", i, *(*r + i));
  }
}

/* main function to call above defined function */
int main ()
{
   /* a pointer to an int */
   int *p = NULL; //null pointer initially, points nowhere
   int i;
   int arrSize;
   printf("Input how many random number you like to generate:");
   scanf("%d", &arrSize);

   getRandom(arrSize, &p );// IS This CORRECT?
   printf("---------------------\n");

   for ( i = 0; i < arrSize; i++ )
   {
       printf( "*(p + %d) : %d\n", i, *(p + i));
       //printf( "*(p + %d) : %d\n", i, p[i] );
   }

   return 0;
}
