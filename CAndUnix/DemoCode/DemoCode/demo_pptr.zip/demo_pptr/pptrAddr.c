
#include <stdio.h>
#include <stdlib.h>
#define R 5
#define C 4

//#define STATIC

int main(int argc, const char * argv[])
{
    
#ifdef STATIC
    // insert code here...
    int  grades[R][C] = {
        { 0, 1, 2, 3},
        { 4, 5, 6, 7 },
        { 8, 9, 10, 11 },
        { 12, 13, 14, 15 },
        { 16, 17, 18, 19}
    };
    
#else
    
    int i,j,walk = 0;
    int **grades = (int **)malloc(R * sizeof(int *));
    for(i = 0; i < R; i ++)
    {
        grades[i] = (int *) malloc( C * sizeof(int) );
    }
    for( i = 0; i < R; i ++)
    {
        for(j = 0; j < C; j ++)
        {
            grades[i][j] = walk ++;
        }
    }
#endif
    
    
    int **pptr = (int **)grades;
    printf("-1: pptr= %p\n", pptr);
    printf("-1: &pptr[0] = %p\n", &pptr[0] );
    printf("-1: pptr+1= %p\n", pptr + 1);
    printf("-1: pptr+2= %p\n", pptr + 2);
    
    printf("\n\n");
    
    printf("0: pptr[0]= %p\n", pptr[0]);
    printf("0: *pptr= %p\n", *pptr);
    printf("0: &pptr[0][0]= %p\n", &pptr[0][0]);

    
    printf("\n\n");
    
    printf("1: pptr[1]= %p\n", pptr[1]);
    printf("1: *(pptr + 1)= %p\n", *(pptr + 1));
    printf("1: &pptr[1][0] = %p\n", &pptr[1][0] );
    
    printf("\n\n");
    
    printf("2: *pptr + 1 = %p\n", *pptr + 1);
    printf("2: *(pptr+0) + 1 = %p\n", *(pptr + 0) + 1);
    printf("2: &pptr[0][1] = %p\n", &pptr[0][1] );
    
    printf("\n\n");
    printf("3: *(pptr[1] + 1) = %d\n", *(pptr[1] + 1) );
    //printf("3: *(grades[1] + 1) = %d\n", *(grades[1] + 1) );
    printf("3: *( *(pptr + 1) + 1) = %d\n", *( * (pptr + 1) + 1) );
    printf("3: pptr[1][1] = %d\n", pptr[1][1] );
    
    //printf("Hello, World!\n");
    return 0;
}


