#include <stdio.h>

int main()
{
	int i = 7, j;
        printf("input a number:");
	scanf("%d", &j);
	int ret = (i == j);
	printf("%d\n", ret);
}

