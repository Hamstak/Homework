
#include <stdio.h>

// function prototypes
int getQuestion1(void); 
int getQuestion2(void);
int getQuestion3(void);
int getQuestion4(void);
int getQuestion5(void);
void outputNumCorrect(int);

// function main begins program execution
int main ( void )
{
   int numCorrect = 0; // number of correct responses

   printf("Welcome to the Global Warming Quiz! Let's begin.\n");
	numCorrect += getQuestion1();
	numCorrect += getQuestion2();
	numCorrect += getQuestion3();
	numCorrect += getQuestion4();
	numCorrect += getQuestion5();
	outputNumCorrect( numCorrect );
} // end main

// Output question 1 & get user's response
int getQuestion1()
{
   int answer;
   puts( "By how much have average temperatures risen since 1880?"
            "\n 1: 0.4 degrees F"
            "\n 2: 1.4 degrees F"
            "\n 3: 2.4 degrees F"
            "\n 4: 3.4 degrees F" );
   scanf( "%d", &answer ); // get the user's answer

   if ( 2 == answer ) {
      puts( "Correct\n" );
   }
   else {
      puts( "The correct answer is 2\n" );
   }

   return 2 == answer;
} // end getQuestion1

// Output question 2 & get user's response
int getQuestion2()
{	
   int answer;
   puts( "Glaciers are melting. Montana's Glacier National Park had 150 glaciers in 1910."
         "\nHow many does it have now?"
         "\n 1: 0"
         "\n 2: 7"
         "\n 3: 17"
         "\n 4: 27" );
   scanf( "%d", &answer ); // get the user's answer

   if ( 4 == answer )
   {
      puts( "Correct\n" );
   }
   else {
      puts( "The correct answer is 4\n" );
   }

   return 4 == answer;
} // end getQuestion2

// Output question 3 & get user's response
int getQuestion3()
{	
   int answer;
   puts( "What is the most abundant greenhouse gas?"
         "\n1: water vapor"
         "\n2: carbon dioxide"
         "\n3: methane"
         "\n4: carbon monoxide" );
   scanf( "%d", &answer ); // get the user's answer

   if ( 1 == answer )
   {
      puts( "Correct\n" );
   }
   else {
      puts( "The correct answer is 1\n" ); 
   }

   return 1 == answer;
} // end getQuestion3

// Output question 4 & get user's response
int getQuestion4()
{	
   int answer;
   puts( "Which of these should you NOT do to help stop global warming?"
         "\n1: Use less hot water"
         "\n2: Reuse your shopping bag"
         "\n3: Plant a tree"
         "\n4: Take a bath instead of a shower" );
   scanf( "%d", &answer ); // get the user's answer

   if ( 4 == answer )
   {
      puts( "Correct\n" );
   }
   else {
      puts( "The correct answer is 4\n" );
   }

   return 4 == answer;
} // end getQuestion4

// Output question 5 & get user's response
int getQuestion5()
{	
   int answer;
   puts( "Which of these should you NOT do to help stop global warming?"
         "\n1: Buy more frozen foods"
         "\n2: Fly less"
         "\n3: Use a clothesline instead of a dryer"
         "\n4: Cover pots while cooking" );
   scanf( "%d", &answer ); // get the user's answer

   if ( 1 == answer )
   {
      puts( "Correct\n" );
   }
   else {
      puts( "The correct answer is 1\n" );
   }

   return 1 == answer;
} // end getQuestion5

// Output the number of questions the user answered correctly
void outputNumCorrect( int correct )
{
   if ( correct < 4 ) {
      puts( "\nTime to brush up on your knowledge of global warming." );
   }
   else if( 4 == correct ) {
      puts( "\nVery good." );
   }
   else {
      puts( "\nExcellent!" );
   }
      
   printf( "You got %d correct.", correct );
   
   puts( "\nFind out more at "
      "\nhttp://news.nationalgeographic.com/news/2004/12/1206_041206_global_warming.html"
      "\nhttp://lwf.ncdc.noaa.gov/oa/climate/gases.html"
      "\nhttp://globalwarming-facts.info/50-tips.html");
} // end outputNumCorrect
