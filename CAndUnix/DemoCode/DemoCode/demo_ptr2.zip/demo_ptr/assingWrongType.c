#include <stdlib.h>
#include <stdio.h>

int main(){
	
	int *ptr = NULL;

//	double *ptr = NULL;
        double d = 1000.0;
        ptr = &d;
        printf("dereference ptr is %d, \n", *ptr);

}
