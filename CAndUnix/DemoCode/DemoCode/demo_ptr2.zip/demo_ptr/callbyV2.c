#include <stdio.h>
#include <stdlib.h>

void foo2( int * );

int main()  
{
        int a = 10;
        int *ptr = &a;
        printf("before you call foo2, ptr is %p\n", ptr);
	foo2( ptr );

        printf("after you call foo2, ptr is %p\n", ptr);
}

void foo2(int *p)
{   
    //int *array = (int *) malloc(5 * sizeof(int));
    int b = 100;
    p = &b;//like an integer variable, if you change the varialbe itself, we cannot see the change outside of the function.
}
