#include <stdio.h>

void foo( int );

int main()  
{
        int a = 10;
        printf("before you call foo, a is %d\n", a);
	foo(a);

        printf("after you call foo, a is %d\n", a);
}

void foo(int i)
{
    i += 100;
}
