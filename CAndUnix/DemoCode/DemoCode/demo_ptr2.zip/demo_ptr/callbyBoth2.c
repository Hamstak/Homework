#include <stdio.h>
#include <stdlib.h>

void foo3( int * );

int main()  
{
        int a = 10;  //assume address of a is 0x7fff54b52bec
        int *ptr; 
        ptr = &a;

        printf("before you call foo3, ptr is %p\n", ptr);
        printf("before you call foo3, *ptr is %d\n", *ptr);
        printf("before you call foo3, a is %d\n", a);

	foo3( &a );

        printf("after you call foo3, ptr is %p\n", ptr);
        printf("after you call foo3, *ptr is %d\n", *ptr);
        printf("after you call foo3, a is %d\n", a);
}

void foo3(int *p)
{  
    int *b = (int *) malloc(1 * sizeof(int));  //assume this statemet returns value of 0x7fff54b72000 
    *(b + 0) = 100;
    p = b; //assign value in b to p
    (*p) = *b ; //assign what b points to into the memory location held by p. 
}
