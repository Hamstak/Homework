#include <stdio.h>
int main ()
{
   int  var1;
   char arr[4];

   printf("Address of var1 variable: %p\n", &var1  );
   printf("Value of arr: %p\n", arr  );
   printf("Address of arr[0] variable: %p\n", &arr[0]  );
   printf("Address of arr[1] variable: %p\n", &arr[1]  );
   printf("Address of arr[2] variable: %p\n", &arr[2]  );
   printf("Address of arr[3] variable: %p\n", &arr[3]  );
   return 0;
}

