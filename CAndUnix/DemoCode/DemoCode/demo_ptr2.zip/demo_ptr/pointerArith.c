#include <stdio.h>
#define MAX 4

int main ()
{
   int arr[] = {10, 20, 30, 40};

   printf("Value of arr: %p\n", arr  );
   printf("Address of arr[0] variable: %p\n", &arr[0]  );
   printf("Address of arr[1] variable: %p\n", &arr[1]  );
   printf("Address of arr[2] variable: %p\n", &arr[2]  );
   printf("Address of arr[3] variable: %p\n\n\n", &arr[3]  );

   int  i, *ptr;
   printf("size of ptr is = %lu\n", sizeof(ptr));
   printf("size of int is = %lu\n", sizeof(i));

   /* let us have array address in pointer */
   ptr = arr;
   for ( i = 0; i < MAX; i++ )
   {

      printf("Value hold by ptr = %p\n", ptr );
      printf("Value that ptr points to = %d\n", *ptr ); //*ptr derefence pointer variable

      /* move to the next location */
      ptr++; //pointer arithmetic, move ptr so that it points to next integer in array
   }
   return 0;
}


